###Tuts+ Tutorial: Coloring Android Apps with Palette

####Instructor: Paul Trebilcox-Ruiz

One of the defining features of material design is the use of color to compliment and emphasize content on the screen. Using the Palette class, developers can extract prominent colors from a bitmap for use in their apps to customize user interface elements.

Source Files for the Tuts+ tutorial: [Coloring Android Apps with Palette](http://code.tutsplus.com/tutorials/coloring-android-apps-with-palette--cms-24096)

**Read this tutorial on [Tuts+](https://code.tutsplus.com)**
