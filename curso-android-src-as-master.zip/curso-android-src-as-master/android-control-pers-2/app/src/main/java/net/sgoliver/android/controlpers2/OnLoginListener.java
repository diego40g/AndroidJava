package net.sgoliver.android.controlpers2;

public interface OnLoginListener {
	void onLogin(String usuario, String password);
}
