package net.sgoliver.android.controlpers3;

public interface OnCasillaSeleccionadaListener
{
    void onCasillaSeleccionada(int fila, int columna);
}