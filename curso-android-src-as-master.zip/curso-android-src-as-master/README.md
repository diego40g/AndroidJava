Código fuente del Curso de Programación Android con Android Studio (www.sgoliver.net)

Si te interesa el curso puedes acceder a él gratuitamente desde su web oficial:

http://www.sgoliver.net/blog/?page_id=2935

Fácil. Gratis. Divertido.